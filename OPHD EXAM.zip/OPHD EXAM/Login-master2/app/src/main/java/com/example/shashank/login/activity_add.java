package com.example.shashank.login;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

public class activity_add extends AppCompatActivity {
    private Button reg;
//    RadioButton female;
    private RadioButton male;
    private DatePicker datePicker;
    private EditText name;
    private RadioGroup radioGroup;
    SQLiteDatabase sqLiteDatabaseObj;
    String SQLiteDataBaseQueryHolder ;
    SQLiteHelper sqLiteHelper;
    Cursor cursor;
    String strDate = "";
    String gender ="Female";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        radioGroup=(RadioGroup)findViewById(R.id.radioGroup);
        male = (RadioButton) findViewById(R.id.radioMale);
        reg = (Button)findViewById(R.id.buttonRegister);
        name = (EditText) findViewById(R.id.editName_reg);


        datePicker = (DatePicker) findViewById(R.id.datePicker);
        int day = datePicker.getDayOfMonth();
        int month = datePicker.getMonth() + 1;
        int year = datePicker.getYear();


        SimpleDateFormat dateFormatter = new SimpleDateFormat("MM-dd-yyyy");
        Date d = new Date(year, month, day);
        strDate = dateFormatter.format(d);
        sqLiteHelper = new SQLiteHelper(this);

        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(name.getText().toString().equalsIgnoreCase("")){
                    Toast.makeText(getApplicationContext(),"Please Provide the name", Toast.LENGTH_LONG).show();
                }else {

                    if (male.isChecked()){
                        gender = "male";
                    }
                    // Creating SQLite database if dose n't exists
                    SQLiteDataBaseBuild();

                    // Creating SQLite table if dose n't exists.
                    SQLiteTableBuild();

                    InsertDataIntoSQLiteDatabase();



                }
            }
        });

        // Empty edittext after done inserting process method.


    }




    // SQLite database build method.
    public void SQLiteDataBaseBuild(){

        sqLiteDatabaseObj = openOrCreateDatabase(SQLiteHelper.DATABASE_NAME, Context.MODE_PRIVATE, null);

    }

    // SQLite table build method.
    public void SQLiteTableBuild() {

        sqLiteDatabaseObj.execSQL("CREATE TABLE IF NOT EXISTS " + "patients" + "(" + "name" + " VARCHAR, " + "dob" + " VARCHAR, " + "gender" + " VARCHAR);");

    }

    // Insert data into SQLite database method.
    public void InsertDataIntoSQLiteDatabase(){

        // If editText is not empty then this block will executed.


            // SQLite query to insert data into table.
            SQLiteDataBaseQueryHolder = "INSERT INTO "+"patients"+" (name,dob,gender) VALUES('"+name+"', '"+strDate+"', '"+gender+"');";

            // Executing query.
            sqLiteDatabaseObj.execSQL(SQLiteDataBaseQueryHolder);

            // Closing SQLite database object.
            sqLiteDatabaseObj.close();

            // Printing toast message after done inserting.
            Toast.makeText(getApplicationContext(),"Patient Registered Successfully", Toast.LENGTH_LONG).show();



    }
}