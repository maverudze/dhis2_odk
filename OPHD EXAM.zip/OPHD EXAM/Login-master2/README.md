# Login-with-SQLite

Register & Login App with SQLite DB

It is a Simple Registration and Login android app with SQLite Database which also works when user is not connected to internet.

It is built to work on Android 5.1 & above

Technologies used: Android, Java, XML, SQLite


